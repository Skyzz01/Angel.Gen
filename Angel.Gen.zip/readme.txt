Angel Gen
1. make sure virus protection off

2. if the gen does not open make sure to run as admin 

3. you will have to regen another acc every 2-4 weeks 

4. any other problems dm har#5152 on discord

5. make sure you have python installed in your pc